const userAuth = (req, res, next) => {
    let age = req.query.age;
    if ( age>= 18){
        res.send("age not velid");
    }else{
        console.log("hello");
        next();
    }
}

module.exports = userAuth;