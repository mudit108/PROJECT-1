const express = require('express');
const userAuth = require('./middlewares/user.middleware');

const app = express();

const port = 1818;

app.set('view engine', 'ejs');

app.use(express.static('public'));

app.get('/', userAuth, (req, res) => {
    return res.render('index');
})

app.get('/authentication-login', userAuth, (req, res) => {
    return res.render('authentication-login');
})

app.get('/form-basic', userAuth, (req, res) => {
    return res.render('form-basic');
})

app.get('/form-wizard', userAuth, (req, res) => {
    return res.render('form-wizard');
})

app.get('/grid', userAuth, (req, res) => {
    return res.render('grid');
})
app.get('/icon-fontawsome', userAuth, (req, res) => {
    return res.render('icon-fontawsome');
})

app.get('/icon-material', userAuth, (req, res) => {
    return res.render('icon-material');
})

app.get('/index', userAuth, (req, res) => {
    return res.render('index');
})

app.get('/index2', userAuth, (req, res) => {
    return res.render('index2');
})

app.get('/pages-buttons', userAuth, (req, res) => {
    return res.render('pages-buttons');
})

app.get('/pages-calender', userAuth, (req, res) => {
    return res.render('pages-calender');
})

app.get('/pages-chat', userAuth, (req, res) => {
    return res.render('pages-chat');
})

app.get('/pages-elements', userAuth, (req, res) => {
    return res.render('pages-elements');
})

app.get('/pages-gallery', userAuth, (req, res) => {
    return res.render('pages-galley');
})
app.get('/page-invoice', userAuth, (req, res) => {
    return res.render('page-invoice');
})

app.get('/tables', userAuth, (req, res) => {
    return res.render('tables');
})

app.get('/widgets', userAuth, (req, res) => {
    return res.render('widgets');
})



app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
